# Spot Welder Control
