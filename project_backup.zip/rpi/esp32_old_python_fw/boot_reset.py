import machine
machine.reset()
